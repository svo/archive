Ansible Clojure
===============
