Ansible OpenJDK
===============
