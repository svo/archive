Ansible Docker Compose
======================
