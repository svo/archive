Ansible Docker
==============
