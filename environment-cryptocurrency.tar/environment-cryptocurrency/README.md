environment-cryptocurrency
==========================

ansible-playbook -i ansible.hosts -k -K playbook.yml
